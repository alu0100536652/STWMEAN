var guachincheApp = angular.module('guachincheApp', ['ngRoute','guachincheAppDirectives','guachincheAppController','guachincheServices']);

guachincheApp.config(function($routeProvider, $locationProvider) {
    $routeProvider
        .when('/', {
            templateUrl : 'views/pages/list.html'
        })
        // 3º Incluir la ruta /new con su plantilla new.html, e incluir la ruta /about con su plantilla about.html
        .otherwise({
            redirectTo: '/'
        })
    
    $locationProvider.html5Mode(true);
})